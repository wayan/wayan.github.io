package Akar::AQ::CDBI;
$Akar::AQ::CDBI::VERSION = '0.001';
use common::sense;

# Class::DBI classes with injected storage
use Akar::AQ::_Listener;
use Akar::AQ::_Daemon;
use Akar::AQ::_Queue;
use Akar::AQ::_AqQueue;

sub build_cdbi_base {
    my ($classno, $storage) = @_;

    my $cdbi_base = _build_class( 'Base', $classno, ['Class::DBI']);
    no strict 'refs';
    *{$cdbi_base . '::db_Main'} = sub { return $storage->dbh };
    return $cdbi_base;
}

sub _build_class {
    my ($prefix, $classno, $base_classes) = @_;

    no strict 'refs';
    my $class = "Akar::AQ::DBIC::Anon::${prefix}::${classno}";
    @{ $class . '::ISA' } = @$base_classes;
    return $class;
}

sub build_daemon_class {
    my ( $cdbi_base, $classno, $opts ) = @_;

    my $control_context = $opts->{control_context};

    my $class = _build_class( 'Daemon', $classno, [ $cdbi_base, 'Akar::AQ::_Daemon']);
    $class->table("$control_context.aq_daemon");
    $class->sequence("$control_context.aq_daemon_seq");
    $class->set_sql( 'Nextval', 'SELECT %s.NEXTVAL from DUAL' );

    # database fields
    $class->columns( 'Primary' => 'id' );
    $class->columns( 'Essential' =>
            qw(queue daemon_num usessionid pid started being_stopped) );
    return $class;
}

sub build_aq_queue_class {
    my ( $cdbi_base, $classno, $opts ) = @_;

    my $class = _build_class( 'AqQueue', $classno, [$cdbi_base] );

    my $control_context = $opts->{control_context};
    $class->table("$control_context.aq_queue");

    # database fields
    $class->columns( 'Primary'   => 'queue' );
    $class->columns( 'Essential' => qw(auto_start) );
    return $class;
}

sub build_queue_class {
    my ( $cdbi_base, $classno, $opts ) = @_;

    my $class = _build_class( 'Queue', $classno,
        [ $cdbi_base, 'Akar::AQ::_Queue' ] );
    my $control_context = $opts->{control_context};
    $class->table('sys.all_queues');

    # database fields
    $class->columns( 'Primary' => 'qid' );
    $class->columns(
        'Essential' => qw(owner name queue_table qid queue_type
            max_retries retry_delay enqueue_enabled dequeue_enabled retention)
    );

    no strict 'refs';
    *{ $class . '::' . 'dequeue_enabled' } = sub {
        return shift()->_dequeue_enabled_accessor =~ /yes/i ? 1 : 0;
    };
    *{ $class . '::' . 'enqueue_enabled' } = sub {
        return shift()->_enqueue_enabled_accessor =~ /yes/i ? 1 : 0;
    };

    return $class;
}

sub build_listener_class {
    my ( $cdbi_base, $classno, $opts ) = @_;

    my $class = _build_class('Listener', $classno, [ $cdbi_base, 'Akar::AQ::_Listener' ] );

    my $control_context = $opts->{control_context};
    $class->table("$control_context.aq_listener");
    $class->sequence("$control_context.aq_daemon_seq");
    $class->set_sql( 'Nextval', 'SELECT %s.NEXTVAL from DUAL' );

    # database fields
    $class->columns( 'Primary' => 'id' );
    $class->columns(
        'Essential' => qw(queue_table
            hostname pid usessionid started)
    );

    return $class;
}

1;

