package Akar::AQ::SuperManager;
$Akar::AQ::SuperManager::VERSION = '0.001';
use strict;
use warnings;

use base qw(Class::Accessor::Fast);

use Carp qw(carp croak);
use Akar::AQ::WaitUntil;

__PACKAGE__->mk_ro_accessors(qw(managers));

sub managers {
    return @{shift()->_managers_accessor};
}

sub controllers {
    return map { $_->controllers } shift()->managers;
}

sub list_queues {
    my ($this) = @_;

    my $last_manager;
    for my $manager ( $this->managers ) {
        # separator
        print "\n\n" if $last_manager;

        $manager->list_queues(1);
        $last_manager = $manager;
    }
    print $last_manager->list_queues_legend;
}

# divide controllers according to managers
# returns list
# manager => \@controllers, manager => \@controllers
sub divide_controllers {
    my ($this, @controllers) = @_;

    my @retval;
    for my $manager ($this->managers){
    }
    return @retval;
}

sub list_messages {
    my ( $this, $selection, $options, @controllers ) = @_;

    for my $controller (@controllers) {
        $controller->list_messages( $selection, $options );
    }
}

sub start_listener {
    my ($this, $waiter) = @_;

    $waiter ||= Akar::AQ::WaitUntil->new;
    for my $manager ($this->managers){
        $manager->retrieve_listener 
        or $manager->start_listener($waiter);
    }
}

sub stop_listener {
    my ($this, $waiter) = @_;

    $waiter ||= Akar::AQ::WaitUntil->new;
    for my $manager ($this->managers){
        $manager->stop_listener($waiter);
    }
}

sub restart_listener {
    my ($this, $waiter) = @_;

    $waiter ||= Akar::AQ::WaitUntil->new;
    for my $manager ($this->managers){
        $manager->restart_listener($waiter);
    }
}

sub start_all_queues {
    my ($this) = @_;

    for my $manager ($this->managers){
        $manager->start_all_queues;
    }
}

1;

__END__

=head1 NAME

Akar::AQ::SuperManager - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
