package Akar::AQ::Accessor;
$Akar::AQ::Accessor::VERSION = '0.001';
use strict;
use warnings;

# ABSTRACT: base class (only) for Akar::AQ::*

# Don't use anywhere else

use Carp qw(carp croak);

sub mk_accessors {
    my $package = shift();

    for my $field (@_){
        $package->_mk_accessor_mutator($field, 0);
    }
}

sub mk_ro_accessors {
    my $package = shift();

    for my $field (@_){
        $package->_mk_accessor_mutator($field, 1);
    }
}

sub _mk_accessor_mutator {
    my ( $package, $field, $read_only ) = @_;

    my $accessor = sub {
        croak
            "Method $field is accessor only, use set_$field to set the value\n"
            if @_ > 1;

        my ($this) = @_;
        croak "Method $field cannot be called on package\n" if !ref($this);
        return $this->{$field};
    };
    my $mutator = sub {
        croak
            "Method set_$field is mutator only, use $field to get the value\n"
            if @_ != 2;

        my ( $this, $new_value ) = @_;
        croak "Method set_$field cannot be called on package\n"
            if !ref($this);

        return $this->{$field} = $new_value;
    };

    no strict 'refs';
    _add_method( "${package}::${field}",           $accessor );
    _add_method( "${package}::_${field}_accessor", $accessor );

    if ( !$read_only ) {
        _add_method( "${package}::set_${field}",      $mutator );
        _add_method( "${package}::_${field}_mutator", $mutator );
    }
}

sub _add_method {
    my ($name, $sub) = @_;

    if (!defined &{$name}){
        no strict 'refs';
        *{$name} = $sub;
    } 
}

sub new {
    my ( $package, $fields ) = @_;

    # make a copy of $fields.
    return bless { %{ $fields || {} } } => $package;
}

1;

__END__

=head1 NAME

Akar::AQ::Accessor - simple accessor/mutator generator

=head1 SYNOPSIS

    package MyClass;
    use base qw(Akar::AQ::Accessor);

    ...
    __PACKAGE__->mk_accessors( qw(apperture shutter_speed) );
    __PACKAGE__->mk_ro_accessors( qw(iso_speed) );

    ...
    warn $this->apperture;
    $this->set_apperture(8);


=head1 DESCRIPTION

The equivalent of Class::Accessor(::Fast), the only difference 
is that accessor/mutator for field I<Field> are two separate 
method I<Field>, set_I<Field>,
with synonyms _I<Field>_accessor, _I<Field>_mutator.

=head1 AUTHOR

Roman Daniel <roman.daniel@gtsnovera.cz>

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
