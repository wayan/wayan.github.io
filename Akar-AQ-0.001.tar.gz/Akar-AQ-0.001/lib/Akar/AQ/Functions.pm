package Akar::AQ::Functions;
$Akar::AQ::Functions::VERSION = '0.001';
use common::sense;

use Exporter 'import';

use Akar::AQ::_QName;

# methods exported on demand (preferred)
our @EXPORT_OK = qw(qname );

# methods exported automatically
our @EXPORT = qw();

use Carp qw(carp croak);

# returns qualified name object
sub qname {
    return Akar::AQ::_QName->new(@_);
}




1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
