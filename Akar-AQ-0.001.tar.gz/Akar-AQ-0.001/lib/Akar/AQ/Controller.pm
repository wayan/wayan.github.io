package Akar::AQ::Controller;
$Akar::AQ::Controller::VERSION = '0.001';
use common::sense;

use base qw(Akar::AQ::Accessor);

use Carp qw(carp croak);
use List::MoreUtils qw(zip first_value);
use Time::HiRes qw(gettimeofday tv_interval);
use Class::Load;

use Akar::DBI::Statement qw(sql_param sql sql_param_inout sql_and sql_join);
use Interpolation 'E' => 'eval', 'sqlp' => sub { return sql_param(@_) };
use Akar::AQ::WaitUntil;
use Akar::AQ::Constants qw(LISTEN_TIMEOUT_ERRNO DEQUEUE_TIMEOUT_ERRNO
    NO_MESSAGE_IN_QUEUE_ERRNO);
use File::Basename qw(basename);


use Types::Standard qw(Str Dict Optional Any slurpy ArrayRef HasMethods);
use Type::Params ();

# queue types
use constant 'NORMAL_QUEUE'    => 'NORMAL_QUEUE';
use constant 'EXCEPTION_QUEUE' => 'EXCEPTION_QUEUE';

use Akar::AQ::Util qw(dbh_err);

__PACKAGE__->mk_ro_accessors(

    # model is a manager
    'queue_class', 'daemon_class', 'aq_queue_class',
    'storage',

    # qualified!! name of the queue table
    'queue',

    'multi_consumer',

    'queue_owner', 'queue_name', 'queue_type', 'payload_type', 'queue_table',
    'queue_table_name', 'sort_order',
    'multi_consumer',

    'message_class',
    'manager',
);
__PACKAGE__->mk_accessors(qw(dequeued errors));

# number of timeouts after which the controller stops
# default is 1
__PACKAGE__->mk_accessors( 'exit_when_timeout');
__PACKAGE__->mk_accessors( 'listen_timeout', 'stop_after' );

__PACKAGE__->mk_ro_accessors(qw(logpath));

# dequeue_options.navigation (values are NEXT_MESSAGE (default), # FIRST_MESSAGE)
__PACKAGE__->mk_ro_accessors(qw(dequeue_navigation));

sub db_Main {
	my ($this) = @_;
	return $this->storage->dbh;
}

# 2013-01-04 danielr - returns the "table" to read the messages from
# for single consumer queues is the queue table directly
my $new_args = Type::Params::compile(
    Any,
    slurpy Dict [
        queue          => Any,
        queue_table    => Any,
        queue_type     => Any,
        payload_type   => Str,
        sort_order     => Str,
        message_class  => Any,
        multi_consumer => Any,
        logpath        => Any,
		daemon_class => Any,
		storage => HasMethods['dbh'],
		manager => Any,
        slurpy Any,
    ]
);

sub new {
    my ($package, $opts) = $new_args->(@_);

    my $queue = $opts->{queue};
    my $queue_table = $opts->{queue_table};
    my ($queue_owner, $queue_name) = split /\./, $queue;
    (undef, my $queue_table_name) = split /\./, $queue;

    # passing the connection method to message class
    my $controller = $package->SUPER::new(
        {   'listen_timeout'     => 2,
            'stop_timeout'       => 20,
            'exit_when_timeout'  => 1,
            'dequeue_navigation' => 'NEXT_MESSAGE',
            'queue_name'       => $queue_name,
            'queue_owner'      => $queue_owner,
            'queue_table_name' => $queue_table_name,
            %$opts,
        }
    );

    $controller->_clean_dead_daemon;
    return $controller;
}

sub _clean_dead_daemon {
    my ($this) = @_;

    my $daemon = $this->retrieve_daemon;
    return if !$daemon || $daemon->is_alive;

    warn "Daemon $E{ $daemon->queue } seems dead\n ";
    $this->storage->txn_do(
        sub {
            $daemon->delete;
        }
    );
}


sub _agent_name {
	my ($this, $daemon) = @_;

	return 'd'. $daemon->id;
}

1;

__END__

=head1 NAME

Akar::AQ::Controller - managing and running one queueu

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: shiftwidth=4:tabstop=4:softtabstop=0:
