package Akar::AQ::_QName;
$Akar::AQ::_QName::VERSION = '0.001';
use strict;
use warnings;

use base qw(Class::Accessor::Fast);

use overload '""' => sub {
    my $this = shift;
    return $this->owner . '.' . $this->name;
    },
    'fallback' => 1;

__PACKAGE__->mk_ro_accessors(qw(owner name));

sub new {
    my $class = shift;
    my ($qname) = @_;

    my @qname = split /\./, $qname;
    @qname == 2 or die "Qualified name expected, not $qname\n ";

    return $class->SUPER::new(
        {   'owner' => $qname[0],
            'name'  => $qname[1],
        }
    );
}

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
