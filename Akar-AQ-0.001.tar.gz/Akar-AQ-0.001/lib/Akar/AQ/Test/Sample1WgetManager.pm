package Akar::AQ::Test::Sample1WgetManager;
$Akar::AQ::Test::Sample1WgetManager::VERSION = '0.001';
use strict;
use warnings;

use base qw(Akar::AQ::CLI);
use Class::Trait qw(Supp::Trait::Dbh);

sub aq_message_class {
    return 'Akar::AQ::Test::Sample1WgetMessage';
}

sub queue_table {
    return 'AKAR.AQS2_SAMPLE1_WGET_QT';
}

1;



