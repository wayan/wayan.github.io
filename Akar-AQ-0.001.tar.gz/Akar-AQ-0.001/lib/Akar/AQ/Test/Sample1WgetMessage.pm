package Akar::AQ::Test::Sample1WgetMessage;
$Akar::AQ::Test::Sample1WgetMessage::VERSION = '0.001';
use strict;
use warnings;


use Carp qw(carp croak);
use base qw(Akar::AQ::Message);
use Data::Dump qw(pp);

sub payload_fields {
    return qw(action aqs2_sample1_wget_id title);
}

__PACKAGE__->mk_accessors(__PACKAGE__->payload_fields);

sub handle {
    my ($this) = @_;

    warn pp($this);
    my $sleep = 10;
    warn "Sleeping $sleep seconds";
    sleep($sleep);
    warn "Sleep finished\n";
}

1;

__END__

=head1 NAME

Akar::AQ::Test::Sample1WgetMessage - SUPPLY SHORT DESCRIPTION OF THE PACKAGE

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 AUTHOR

=cut

vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
