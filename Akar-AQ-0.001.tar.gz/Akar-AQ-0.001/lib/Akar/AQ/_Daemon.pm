package Akar::AQ::_Daemon;
$Akar::AQ::_Daemon::VERSION = '0.001';
use common::sense;

use Carp qw(carp croak);

use Akar::DBI::Statement qw(sql_param sql sql_param_inout sql_and sql_join);
use Interpolation 'E' => 'eval', 'sqlp' => sub { return sql_param(@_) };

# returns 1 if the daemon usessionid is the same as id of existing session
sub is_alive {
    my ($this) = @_;

    return 0 if !$this->usessionid;

    my $is_alive;
    my $is_alive_sqlp = sql_param_inout( \$is_alive, 20 );
    $this->db_Main->do(<<"END_PSQL");
        BEGIN
            if DBMS_SESSION.IS_SESSION_ALIVE($sqlp{ $this->usessionid}) then
                $is_alive_sqlp := 1;
            else
                $is_alive_sqlp := 0;
            end if;
        END;
END_PSQL
   return $is_alive;
}

# the name to use in dbms_aq operations
sub agent_name {
    my ($this) = @_;
    return 'd'. $this->id;
}

1;

