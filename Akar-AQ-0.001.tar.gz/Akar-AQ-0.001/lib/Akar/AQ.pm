package Akar::AQ;
$Akar::AQ::VERSION = '0.001';
use strict;
use warnings;

# ABSTRACT: Oracle Advanced queueing based application

use Carp qw(carp croak);

1;

# vim: expandtab:shiftwidth=4:tabstop=4:softtabstop=0:textwidth=78:
