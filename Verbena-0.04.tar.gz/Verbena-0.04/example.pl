use common::sense;

my $basic_auth = constructor( 'Plack::Midleware::Auth::Basic', 'wrap' );
svc_named(
    {},
    sub {
        my @args = @_;
        sub {
            return $basic_auth->( shift(), @args );
        };
    }
);

sub svc_mw {
    my ( $class, $deps ) = @_;
    my $mw = constructor( $class, 'wrap' );
    svc_named(
        $deps,
        sub {
            my @args = @_;
            sub { $mw->( shift(), @args ) }
        }
    );
}

svc_named(
    {},
    sub {
        my @args = @_;
        sub {
            my $app = shift;
            return builder {
		enable $class, @args;
		$app;
	    };
            }
    }
);

